../h264enc welsenc_vd_1d.cfg
../h264enc welsenc_vd_rc.cfg
../h264enc welsenc_arbitrary_res.cfg

../h264dec ../res/test_vd_1d.264 test_vd_1d.yuv
../h264dec ../res/test_vd_rc.264 test_vd_rc.yuv
../h264dec ../res/Static.264 Static.yuv
